--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Debian 16.8-1.pgdg120+1)
-- Dumped by pg_dump version 16.8 (Debian 16.8-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    organization_id uuid,
    action character varying(255) NOT NULL,
    resource_type character varying(100) NOT NULL,
    resource_id uuid,
    old_values jsonb,
    new_values jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: context_effectiveness; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.context_effectiveness (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    context_pattern text NOT NULL,
    query_type character varying(100) NOT NULL,
    success_rate numeric(5,4) NOT NULL,
    avg_response_quality numeric(3,2),
    usage_count integer DEFAULT 1 NOT NULL,
    last_updated timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.context_effectiveness OWNER TO postgres;

--
-- Name: conversation_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversation_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    conversation_id uuid NOT NULL,
    message_type character varying(50) NOT NULL,
    content text NOT NULL,
    content_embedding character varying,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    relevance_score numeric(5,4),
    explanation text,
    tokens_used integer,
    processing_time_ms integer,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversation_messages OWNER TO postgres;

--
-- Name: conversation_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversation_recommendations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    conversation_id uuid NOT NULL,
    message_id uuid,
    recommendation_type character varying(100) NOT NULL,
    recommended_item_id uuid,
    recommended_item_type character varying(100),
    confidence_score numeric(5,4),
    reasoning text,
    user_feedback character varying(50),
    feedback_notes text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversation_recommendations OWNER TO postgres;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    title character varying(500),
    conversation_type character varying(100) DEFAULT 'discovery'::character varying NOT NULL,
    context_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    context_embedding character varying,
    current_step character varying(100),
    completion_percentage integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: data_sync_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_sync_status (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    sync_type character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    records_processed integer DEFAULT 0 NOT NULL,
    records_updated integer DEFAULT 0 NOT NULL,
    records_created integer DEFAULT 0 NOT NULL,
    errors jsonb DEFAULT '[]'::jsonb NOT NULL,
    started_at timestamp(6) with time zone NOT NULL,
    completed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.data_sync_status OWNER TO postgres;

--
-- Name: intelligent_context_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.intelligent_context_cache (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    cache_key character varying(255) NOT NULL,
    context_data jsonb NOT NULL,
    relevance_tags text[],
    context_embedding character varying,
    access_count integer DEFAULT 0 NOT NULL,
    hit_rate numeric(5,4) DEFAULT 0 NOT NULL,
    last_accessed timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.intelligent_context_cache OWNER TO postgres;

--
-- Name: iris_core_metric_set_indicators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_core_metric_set_indicators (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    core_metric_set_id uuid NOT NULL,
    indicator_id uuid NOT NULL,
    priority_level integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_core_metric_set_indicators OWNER TO postgres;

--
-- Name: iris_core_metric_sets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_core_metric_sets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    purpose text,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_core_metric_sets OWNER TO postgres;

--
-- Name: iris_data_requirements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_data_requirements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    iris_code character varying(100),
    name character varying(255) NOT NULL,
    description text,
    definition text,
    calculation text,
    usage_guidance text,
    data_type character varying(100),
    unit_of_measurement character varying(100),
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_data_requirements OWNER TO postgres;

--
-- Name: iris_goal_key_dimensions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_goal_key_dimensions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    goal_id uuid NOT NULL,
    key_dimension_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_goal_key_dimensions OWNER TO postgres;

--
-- Name: iris_goal_sdgs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_goal_sdgs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    goal_id uuid NOT NULL,
    sdg_id uuid NOT NULL,
    alignment_strength integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_goal_sdgs OWNER TO postgres;

--
-- Name: iris_impact_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_impact_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    embedding character varying,
    embedding_model character varying(100) DEFAULT 'text-embedding-ada-002'::character varying,
    embedding_updated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_impact_categories OWNER TO postgres;

--
-- Name: iris_impact_themes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_impact_themes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    category_id uuid NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    embedding character varying,
    embedding_model character varying(100) DEFAULT 'text-embedding-ada-002'::character varying,
    embedding_updated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_impact_themes OWNER TO postgres;

--
-- Name: iris_indicator_data_requirements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_indicator_data_requirements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    indicator_id uuid NOT NULL,
    data_requirement_id uuid NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    calculation_weight numeric(5,2) DEFAULT 1.0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_indicator_data_requirements OWNER TO postgres;

--
-- Name: iris_key_dimension_core_metric_sets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_key_dimension_core_metric_sets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    key_dimension_id uuid NOT NULL,
    core_metric_set_id uuid NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_key_dimension_core_metric_sets OWNER TO postgres;

--
-- Name: iris_key_dimensions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_key_dimensions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    purpose text,
    sort_order integer DEFAULT 0 NOT NULL,
    embedding character varying,
    embedding_model character varying(100) DEFAULT 'text-embedding-ada-002'::character varying,
    embedding_updated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_key_dimensions OWNER TO postgres;

--
-- Name: iris_key_indicators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_key_indicators (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    calculation_guidance text,
    why_important text,
    data_collection_frequency character varying(100),
    complexity_level character varying(50) DEFAULT 'intermediate'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    embedding character varying,
    embedding_model character varying(100) DEFAULT 'text-embedding-ada-002'::character varying,
    embedding_updated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_key_indicators OWNER TO postgres;

--
-- Name: iris_strategic_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_strategic_goals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    definition text,
    sort_order integer DEFAULT 0 NOT NULL,
    embedding character varying,
    embedding_model character varying(100) DEFAULT 'text-embedding-ada-002'::character varying,
    embedding_updated_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_strategic_goals OWNER TO postgres;

--
-- Name: iris_theme_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iris_theme_goals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    theme_id uuid NOT NULL,
    goal_id uuid NOT NULL,
    relationship_strength integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.iris_theme_goals OWNER TO postgres;

--
-- Name: llm_content_chunks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_content_chunks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    embedding character varying NOT NULL,
    query_keywords text[],
    semantic_tags text[] DEFAULT ARRAY[]::text[],
    content_markdown text NOT NULL,
    content_type character varying(50) NOT NULL,
    context_level integer NOT NULL,
    completeness_score numeric(3,2) DEFAULT 0.8 NOT NULL,
    clarity_score numeric(3,2) DEFAULT 0.8 NOT NULL,
    actionability_score numeric(3,2) DEFAULT 0.8 NOT NULL,
    source_entities jsonb DEFAULT '{}'::jsonb NOT NULL,
    cross_references text[] DEFAULT ARRAY[]::text[],
    access_frequency integer DEFAULT 0 NOT NULL,
    hit_rate numeric(5,4) DEFAULT 0 NOT NULL,
    last_accessed timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.llm_content_chunks OWNER TO postgres;

--
-- Name: llm_training_pairs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_training_pairs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    conversation_id uuid,
    user_input text NOT NULL,
    assistant_response text NOT NULL,
    context_data jsonb NOT NULL,
    quality_score numeric(3,2),
    user_satisfaction integer,
    improvement_notes text,
    embedding character varying,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.llm_training_pairs OWNER TO postgres;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    industry character varying(100),
    size_category character varying(50),
    country character varying(100),
    website character varying(255),
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: query_optimization_recommendations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.query_optimization_recommendations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    query_pattern_id uuid NOT NULL,
    optimization_type character varying(100) NOT NULL,
    recommendation text NOT NULL,
    confidence_score numeric(5,4) NOT NULL,
    implementation_priority integer DEFAULT 5 NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    implemented_at timestamp(6) with time zone
);


ALTER TABLE public.query_optimization_recommendations OWNER TO postgres;

--
-- Name: query_patterns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.query_patterns (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    query_text text NOT NULL,
    query_vector character varying,
    intent_classification character varying(100),
    entities_extracted jsonb DEFAULT '[]'::jsonb NOT NULL,
    successful_results_count integer DEFAULT 0 NOT NULL,
    total_usage_count integer DEFAULT 1 NOT NULL,
    avg_user_satisfaction numeric(3,2),
    context_embedding character varying,
    improvement_suggestions jsonb DEFAULT '{}'::jsonb NOT NULL,
    learning_weight numeric(5,4) DEFAULT 1.0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.query_patterns OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: sdg_indicators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdg_indicators (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    indicator_code character varying(50) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    target_id uuid NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sdg_indicators OWNER TO postgres;

--
-- Name: sdg_targets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sdg_targets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    target_code character varying(20) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    sdg_id uuid NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sdg_targets OWNER TO postgres;

--
-- Name: sustainable_development_goals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sustainable_development_goals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    airtable_id character varying(255) NOT NULL,
    sdg_number integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    color_hex character varying(7),
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sustainable_development_goals OWNER TO postgres;

--
-- Name: user_custom_indicators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_custom_indicators (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    calculation_method text,
    data_collection_guidance text,
    frequency character varying(100),
    approval_status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    approved_by uuid,
    approved_at timestamp(6) with time zone,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_custom_indicators OWNER TO postgres;

--
-- Name: user_measurements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_measurements (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    user_id uuid NOT NULL,
    strategic_goal_id uuid,
    indicator_id uuid,
    custom_indicator_id uuid,
    measurement_period_start date NOT NULL,
    measurement_period_end date NOT NULL,
    value numeric(15,4),
    unit character varying(100),
    methodology text,
    data_quality_score integer,
    notes text,
    attachments jsonb DEFAULT '[]'::jsonb NOT NULL,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    verified_by uuid,
    verified_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_measurements OWNER TO postgres;

--
-- Name: user_organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_organizations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    organization_id uuid NOT NULL,
    role_id uuid NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    joined_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_organizations OWNER TO postgres;

--
-- Name: user_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_reports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid NOT NULL,
    created_by uuid NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    report_type character varying(100) NOT NULL,
    period_start date,
    period_end date,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    template_id uuid,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    shared_with jsonb DEFAULT '[]'::jsonb NOT NULL,
    export_formats jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_reports OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255),
    first_name character varying(100),
    last_name character varying(100),
    job_title character varying(255),
    phone character varying(50),
    preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_login_at timestamp(6) with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: vector_similarity_cache; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vector_similarity_cache (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    query_embedding character varying NOT NULL,
    similar_content_ids text[],
    similarity_scores numeric(65,30)[],
    query_hash character varying(64) NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.vector_similarity_cache OWNER TO postgres;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, organization_id, action, resource_type, resource_id, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: context_effectiveness; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.context_effectiveness (id, context_pattern, query_type, success_rate, avg_response_quality, usage_count, last_updated) FROM stdin;
\.


--
-- Data for Name: conversation_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversation_messages (id, conversation_id, message_type, content, content_embedding, metadata, relevance_score, explanation, tokens_used, processing_time_ms, created_at) FROM stdin;
\.


--
-- Data for Name: conversation_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversation_recommendations (id, conversation_id, message_id, recommendation_type, recommended_item_id, recommended_item_type, confidence_score, reasoning, user_feedback, feedback_notes, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, user_id, organization_id, title, conversation_type, context_data, context_embedding, current_step, completion_percentage, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_sync_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_sync_status (id, sync_type, status, records_processed, records_updated, records_created, errors, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: intelligent_context_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.intelligent_context_cache (id, cache_key, context_data, relevance_tags, context_embedding, access_count, hit_rate, last_accessed, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: iris_core_metric_set_indicators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_core_metric_set_indicators (id, core_metric_set_id, indicator_id, priority_level, created_at) FROM stdin;
\.


--
-- Data for Name: iris_core_metric_sets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_core_metric_sets (id, airtable_id, name, description, purpose, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iris_data_requirements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_data_requirements (id, airtable_id, iris_code, name, description, definition, calculation, usage_guidance, data_type, unit_of_measurement, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iris_goal_key_dimensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_goal_key_dimensions (id, goal_id, key_dimension_id, created_at) FROM stdin;
\.


--
-- Data for Name: iris_goal_sdgs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_goal_sdgs (id, goal_id, sdg_id, alignment_strength, created_at) FROM stdin;
\.


--
-- Data for Name: iris_impact_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_impact_categories (id, airtable_id, name, description, sort_order, embedding, embedding_model, embedding_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iris_impact_themes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_impact_themes (id, airtable_id, name, description, category_id, sort_order, embedding, embedding_model, embedding_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iris_indicator_data_requirements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_indicator_data_requirements (id, indicator_id, data_requirement_id, is_required, calculation_weight, created_at) FROM stdin;
\.


--
-- Data for Name: iris_key_dimension_core_metric_sets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_key_dimension_core_metric_sets (id, key_dimension_id, core_metric_set_id, created_at) FROM stdin;
\.


--
-- Data for Name: iris_key_dimensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_key_dimensions (id, airtable_id, name, description, purpose, sort_order, embedding, embedding_model, embedding_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iris_key_indicators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_key_indicators (id, airtable_id, name, description, calculation_guidance, why_important, data_collection_frequency, complexity_level, sort_order, embedding, embedding_model, embedding_updated_at, created_at, updated_at) FROM stdin;
7f0dc966-e44c-4489-978b-4216234e9039	demo-output-1	Number of training sessions delivered	Count of educational or capacity-building sessions provided to beneficiaries	Count each completed training session	Track training delivery activities to ensure program is operating as planned	monthly	basic	0	\N	text-embedding-ada-002	\N	2025-06-17 09:28:59.913+00	2025-06-17 09:28:59.913+00
e66ab7fe-45de-4330-90af-524e8fffb197	demo-outcome-1	Percentage of trainees demonstrating improved skills	Proportion of participants showing measurable skill improvement after training	Assess skills before and after training using standardized assessments	Measure learning effectiveness and skill development to evaluate program quality	per cohort	intermediate	0	\N	text-embedding-ada-002	\N	2025-06-17 09:28:59.913+00	2025-06-17 09:28:59.913+00
d4dd45fa-e607-403f-8ffa-eb3018e76275	demo-impact-1	Average income increase of employed graduates	Mean change in income for graduates who gained employment	Compare income before training with income 12 months after employment	Measure long-term economic impact of training programs on beneficiary wellbeing	annually	advanced	0	\N	text-embedding-ada-002	\N	2025-06-17 09:28:59.913+00	2025-06-17 09:28:59.913+00
518030f1-5c04-4099-9466-f43406dfab5d	demo-output-2	Number of individuals trained	Total count of unique individuals who completed training programs	Count unique participants who completed the full program	Track participation in training programs to measure reach	monthly	basic	0	\N	text-embedding-ada-002	\N	2025-06-17 09:28:59.913+00	2025-06-17 09:28:59.913+00
71c9511f-419b-49fc-a024-c395ee8346b9	demo-outcome-2	Employment rate of program graduates	Percentage of training completers who gain employment within 6 months	Track employment status 6 months after program completion	Measure program effectiveness in achieving employment outcomes	quarterly	intermediate	0	\N	text-embedding-ada-002	\N	2025-06-17 09:28:59.913+00	2025-06-17 09:28:59.913+00
\.


--
-- Data for Name: iris_strategic_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_strategic_goals (id, airtable_id, name, description, definition, sort_order, embedding, embedding_model, embedding_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: iris_theme_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iris_theme_goals (id, theme_id, goal_id, relationship_strength, created_at) FROM stdin;
\.


--
-- Data for Name: llm_content_chunks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_content_chunks (id, embedding, query_keywords, semantic_tags, content_markdown, content_type, context_level, completeness_score, clarity_score, actionability_score, source_entities, cross_references, access_frequency, hit_rate, last_accessed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: llm_training_pairs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_training_pairs (id, conversation_id, user_input, assistant_response, context_data, quality_score, user_satisfaction, improvement_notes, embedding, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, name, description, industry, size_category, country, website, settings, is_active, created_at, updated_at) FROM stdin;
52b5c0e2-694a-459c-aec6-5e30c112122d	Demo Impact Organization	A demonstration organization for testing the pitfall prevention system	Social Services	Medium	United States	https://demo-impact-org.com	{"warningLevel": "detailed", "foundationFirst": true, "enablePitfallWarnings": true}	t	2025-06-17 09:28:59.599+00	2025-06-17 09:28:59.599+00
4ed33550-5ea7-4a80-8271-cdfb0b5d9a23	Demo Impact Organization	A demonstration organization for testing the pitfall prevention system	Social Services	Medium	United States	https://demo-impact-org.com	{"warningLevel": "detailed", "foundationFirst": true, "enablePitfallWarnings": true}	t	2025-06-17 09:29:53.914+00	2025-06-17 09:29:53.914+00
fbe01e96-3a05-4ffb-9e7f-0a3f18723900	Demo Impact Organization	\N	\N	\N	\N	\N	{}	t	2025-06-17 21:43:46.021+00	2025-06-17 21:43:46.021+00
\.


--
-- Data for Name: query_optimization_recommendations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.query_optimization_recommendations (id, query_pattern_id, optimization_type, recommendation, confidence_score, implementation_priority, status, created_at, implemented_at) FROM stdin;
\.


--
-- Data for Name: query_patterns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.query_patterns (id, query_text, query_vector, intent_classification, entities_extracted, successful_results_count, total_usage_count, avg_user_satisfaction, context_embedding, improvement_suggestions, learning_weight, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name, description, permissions, created_at, updated_at) FROM stdin;
cfef1644-4cc4-4b63-9aa6-10a9ea1b7899	admin	Administrator role with full access	["read", "write", "admin"]	2025-06-17 09:28:59.908+00	2025-06-17 09:28:59.908+00
978e666d-3424-4857-9917-b10a58a5eab1	user	Standard user access	["measurement:read", "measurement:create", "report:read", "conversation:*"]	2025-06-17 21:43:46.023+00	2025-06-17 21:43:46.023+00
\.


--
-- Data for Name: sdg_indicators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdg_indicators (id, airtable_id, indicator_code, name, description, target_id, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sdg_targets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sdg_targets (id, airtable_id, target_code, name, description, sdg_id, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sustainable_development_goals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sustainable_development_goals (id, airtable_id, sdg_number, name, description, color_hex, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_custom_indicators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_custom_indicators (id, organization_id, created_by, name, description, calculation_method, data_collection_guidance, frequency, approval_status, approved_by, approved_at, tags, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_measurements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_measurements (id, organization_id, user_id, strategic_goal_id, indicator_id, custom_indicator_id, measurement_period_start, measurement_period_end, value, unit, methodology, data_quality_score, notes, attachments, status, verified_by, verified_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_organizations (id, user_id, organization_id, role_id, is_primary, joined_at) FROM stdin;
832ba750-0329-450f-8fea-44d914277db6	5f0bf59a-68fe-4c37-a29d-cb4f1a800249	52b5c0e2-694a-459c-aec6-5e30c112122d	cfef1644-4cc4-4b63-9aa6-10a9ea1b7899	t	2025-06-17 09:28:59.91+00
01565424-288a-4a38-9b1c-bdeae5e16b5a	09e7335c-536e-45fb-8d4c-cd5a348d4442	fbe01e96-3a05-4ffb-9e7f-0a3f18723900	978e666d-3424-4857-9917-b10a58a5eab1	t	2025-06-17 21:43:46.029+00
\.


--
-- Data for Name: user_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_reports (id, organization_id, created_by, title, description, report_type, period_start, period_end, content, template_id, status, shared_with, export_formats, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, first_name, last_name, job_title, phone, preferences, last_login_at, is_active, created_at, updated_at) FROM stdin;
09e7335c-536e-45fb-8d4c-cd5a348d4442	demo@impactbot.com	$2a$12$yvFzN/FhXvKg397kJ3EJR.CzukVa0yBCf2gxuiJOJvjbMEisjkAem	Demo	User	\N	\N	{}	2025-06-17 21:43:46.321+00	t	2025-06-17 21:43:45.999+00	2025-06-17 21:43:46.321+00
5f0bf59a-68fe-4c37-a29d-cb4f1a800249	demo@impact-bot.com	$2a$12$Kw7GVGDYfayMCQkCfBHDdeeUMotFFNdZ9/ASMwwKi5rfsWq0lms/u	Demo	User	Program Manager	\N	{}	2025-06-18 04:53:21.683+00	t	2025-06-17 09:28:59.902+00	2025-06-18 04:53:21.684+00
\.


--
-- Data for Name: vector_similarity_cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vector_similarity_cache (id, query_embedding, similar_content_ids, similarity_scores, query_hash, expires_at, created_at) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: context_effectiveness context_effectiveness_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.context_effectiveness
    ADD CONSTRAINT context_effectiveness_pkey PRIMARY KEY (id);


--
-- Name: conversation_messages conversation_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_pkey PRIMARY KEY (id);


--
-- Name: conversation_recommendations conversation_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_recommendations
    ADD CONSTRAINT conversation_recommendations_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: data_sync_status data_sync_status_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_sync_status
    ADD CONSTRAINT data_sync_status_pkey PRIMARY KEY (id);


--
-- Name: intelligent_context_cache intelligent_context_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.intelligent_context_cache
    ADD CONSTRAINT intelligent_context_cache_pkey PRIMARY KEY (id);


--
-- Name: iris_core_metric_set_indicators iris_core_metric_set_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_core_metric_set_indicators
    ADD CONSTRAINT iris_core_metric_set_indicators_pkey PRIMARY KEY (id);


--
-- Name: iris_core_metric_sets iris_core_metric_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_core_metric_sets
    ADD CONSTRAINT iris_core_metric_sets_pkey PRIMARY KEY (id);


--
-- Name: iris_data_requirements iris_data_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_data_requirements
    ADD CONSTRAINT iris_data_requirements_pkey PRIMARY KEY (id);


--
-- Name: iris_goal_key_dimensions iris_goal_key_dimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_goal_key_dimensions
    ADD CONSTRAINT iris_goal_key_dimensions_pkey PRIMARY KEY (id);


--
-- Name: iris_goal_sdgs iris_goal_sdgs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_goal_sdgs
    ADD CONSTRAINT iris_goal_sdgs_pkey PRIMARY KEY (id);


--
-- Name: iris_impact_categories iris_impact_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_impact_categories
    ADD CONSTRAINT iris_impact_categories_pkey PRIMARY KEY (id);


--
-- Name: iris_impact_themes iris_impact_themes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_impact_themes
    ADD CONSTRAINT iris_impact_themes_pkey PRIMARY KEY (id);


--
-- Name: iris_indicator_data_requirements iris_indicator_data_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_indicator_data_requirements
    ADD CONSTRAINT iris_indicator_data_requirements_pkey PRIMARY KEY (id);


--
-- Name: iris_key_dimension_core_metric_sets iris_key_dimension_core_metric_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_key_dimension_core_metric_sets
    ADD CONSTRAINT iris_key_dimension_core_metric_sets_pkey PRIMARY KEY (id);


--
-- Name: iris_key_dimensions iris_key_dimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_key_dimensions
    ADD CONSTRAINT iris_key_dimensions_pkey PRIMARY KEY (id);


--
-- Name: iris_key_indicators iris_key_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_key_indicators
    ADD CONSTRAINT iris_key_indicators_pkey PRIMARY KEY (id);


--
-- Name: iris_strategic_goals iris_strategic_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_strategic_goals
    ADD CONSTRAINT iris_strategic_goals_pkey PRIMARY KEY (id);


--
-- Name: iris_theme_goals iris_theme_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_theme_goals
    ADD CONSTRAINT iris_theme_goals_pkey PRIMARY KEY (id);


--
-- Name: llm_content_chunks llm_content_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_content_chunks
    ADD CONSTRAINT llm_content_chunks_pkey PRIMARY KEY (id);


--
-- Name: llm_training_pairs llm_training_pairs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_training_pairs
    ADD CONSTRAINT llm_training_pairs_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: query_optimization_recommendations query_optimization_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.query_optimization_recommendations
    ADD CONSTRAINT query_optimization_recommendations_pkey PRIMARY KEY (id);


--
-- Name: query_patterns query_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.query_patterns
    ADD CONSTRAINT query_patterns_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sdg_indicators sdg_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdg_indicators
    ADD CONSTRAINT sdg_indicators_pkey PRIMARY KEY (id);


--
-- Name: sdg_targets sdg_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdg_targets
    ADD CONSTRAINT sdg_targets_pkey PRIMARY KEY (id);


--
-- Name: sustainable_development_goals sustainable_development_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sustainable_development_goals
    ADD CONSTRAINT sustainable_development_goals_pkey PRIMARY KEY (id);


--
-- Name: user_custom_indicators user_custom_indicators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_custom_indicators
    ADD CONSTRAINT user_custom_indicators_pkey PRIMARY KEY (id);


--
-- Name: user_measurements user_measurements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_measurements
    ADD CONSTRAINT user_measurements_pkey PRIMARY KEY (id);


--
-- Name: user_organizations user_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_pkey PRIMARY KEY (id);


--
-- Name: user_reports user_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_reports
    ADD CONSTRAINT user_reports_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vector_similarity_cache vector_similarity_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vector_similarity_cache
    ADD CONSTRAINT vector_similarity_cache_pkey PRIMARY KEY (id);


--
-- Name: intelligent_context_cache_cache_key_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX intelligent_context_cache_cache_key_key ON public.intelligent_context_cache USING btree (cache_key);


--
-- Name: iris_core_metric_set_indicators_core_metric_set_id_indicato_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_core_metric_set_indicators_core_metric_set_id_indicato_key ON public.iris_core_metric_set_indicators USING btree (core_metric_set_id, indicator_id);


--
-- Name: iris_core_metric_sets_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_core_metric_sets_airtable_id_key ON public.iris_core_metric_sets USING btree (airtable_id);


--
-- Name: iris_data_requirements_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_data_requirements_airtable_id_key ON public.iris_data_requirements USING btree (airtable_id);


--
-- Name: iris_goal_key_dimensions_goal_id_key_dimension_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_goal_key_dimensions_goal_id_key_dimension_id_key ON public.iris_goal_key_dimensions USING btree (goal_id, key_dimension_id);


--
-- Name: iris_goal_sdgs_goal_id_sdg_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_goal_sdgs_goal_id_sdg_id_key ON public.iris_goal_sdgs USING btree (goal_id, sdg_id);


--
-- Name: iris_impact_categories_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_impact_categories_airtable_id_key ON public.iris_impact_categories USING btree (airtable_id);


--
-- Name: iris_impact_themes_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_impact_themes_airtable_id_key ON public.iris_impact_themes USING btree (airtable_id);


--
-- Name: iris_indicator_data_requirements_indicator_id_data_requirem_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_indicator_data_requirements_indicator_id_data_requirem_key ON public.iris_indicator_data_requirements USING btree (indicator_id, data_requirement_id);


--
-- Name: iris_key_dimension_core_metric_sets_key_dimension_id_core_m_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_key_dimension_core_metric_sets_key_dimension_id_core_m_key ON public.iris_key_dimension_core_metric_sets USING btree (key_dimension_id, core_metric_set_id);


--
-- Name: iris_key_dimensions_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_key_dimensions_airtable_id_key ON public.iris_key_dimensions USING btree (airtable_id);


--
-- Name: iris_key_indicators_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_key_indicators_airtable_id_key ON public.iris_key_indicators USING btree (airtable_id);


--
-- Name: iris_strategic_goals_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_strategic_goals_airtable_id_key ON public.iris_strategic_goals USING btree (airtable_id);


--
-- Name: iris_theme_goals_theme_id_goal_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX iris_theme_goals_theme_id_goal_id_key ON public.iris_theme_goals USING btree (theme_id, goal_id);


--
-- Name: roles_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX roles_name_key ON public.roles USING btree (name);


--
-- Name: sdg_indicators_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sdg_indicators_airtable_id_key ON public.sdg_indicators USING btree (airtable_id);


--
-- Name: sdg_targets_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sdg_targets_airtable_id_key ON public.sdg_targets USING btree (airtable_id);


--
-- Name: sustainable_development_goals_airtable_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sustainable_development_goals_airtable_id_key ON public.sustainable_development_goals USING btree (airtable_id);


--
-- Name: sustainable_development_goals_sdg_number_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX sustainable_development_goals_sdg_number_key ON public.sustainable_development_goals USING btree (sdg_number);


--
-- Name: user_organizations_user_id_organization_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX user_organizations_user_id_organization_id_key ON public.user_organizations USING btree (user_id, organization_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: vector_similarity_cache_query_hash_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX vector_similarity_cache_query_hash_key ON public.vector_similarity_cache USING btree (query_hash);


--
-- Name: audit_logs audit_logs_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: conversation_messages conversation_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversation_recommendations conversation_recommendations_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_recommendations
    ADD CONSTRAINT conversation_recommendations_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversation_recommendations conversation_recommendations_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_recommendations
    ADD CONSTRAINT conversation_recommendations_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.conversation_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversations conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_core_metric_set_indicators iris_core_metric_set_indicators_core_metric_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_core_metric_set_indicators
    ADD CONSTRAINT iris_core_metric_set_indicators_core_metric_set_id_fkey FOREIGN KEY (core_metric_set_id) REFERENCES public.iris_core_metric_sets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_core_metric_set_indicators iris_core_metric_set_indicators_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_core_metric_set_indicators
    ADD CONSTRAINT iris_core_metric_set_indicators_indicator_id_fkey FOREIGN KEY (indicator_id) REFERENCES public.iris_key_indicators(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_goal_key_dimensions iris_goal_key_dimensions_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_goal_key_dimensions
    ADD CONSTRAINT iris_goal_key_dimensions_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.iris_strategic_goals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_goal_key_dimensions iris_goal_key_dimensions_key_dimension_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_goal_key_dimensions
    ADD CONSTRAINT iris_goal_key_dimensions_key_dimension_id_fkey FOREIGN KEY (key_dimension_id) REFERENCES public.iris_key_dimensions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_goal_sdgs iris_goal_sdgs_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_goal_sdgs
    ADD CONSTRAINT iris_goal_sdgs_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.iris_strategic_goals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_goal_sdgs iris_goal_sdgs_sdg_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_goal_sdgs
    ADD CONSTRAINT iris_goal_sdgs_sdg_id_fkey FOREIGN KEY (sdg_id) REFERENCES public.sustainable_development_goals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_impact_themes iris_impact_themes_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_impact_themes
    ADD CONSTRAINT iris_impact_themes_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.iris_impact_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_indicator_data_requirements iris_indicator_data_requirements_data_requirement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_indicator_data_requirements
    ADD CONSTRAINT iris_indicator_data_requirements_data_requirement_id_fkey FOREIGN KEY (data_requirement_id) REFERENCES public.iris_data_requirements(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_indicator_data_requirements iris_indicator_data_requirements_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_indicator_data_requirements
    ADD CONSTRAINT iris_indicator_data_requirements_indicator_id_fkey FOREIGN KEY (indicator_id) REFERENCES public.iris_key_indicators(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_key_dimension_core_metric_sets iris_key_dimension_core_metric_sets_core_metric_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_key_dimension_core_metric_sets
    ADD CONSTRAINT iris_key_dimension_core_metric_sets_core_metric_set_id_fkey FOREIGN KEY (core_metric_set_id) REFERENCES public.iris_core_metric_sets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_key_dimension_core_metric_sets iris_key_dimension_core_metric_sets_key_dimension_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_key_dimension_core_metric_sets
    ADD CONSTRAINT iris_key_dimension_core_metric_sets_key_dimension_id_fkey FOREIGN KEY (key_dimension_id) REFERENCES public.iris_key_dimensions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_theme_goals iris_theme_goals_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_theme_goals
    ADD CONSTRAINT iris_theme_goals_goal_id_fkey FOREIGN KEY (goal_id) REFERENCES public.iris_strategic_goals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: iris_theme_goals iris_theme_goals_theme_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iris_theme_goals
    ADD CONSTRAINT iris_theme_goals_theme_id_fkey FOREIGN KEY (theme_id) REFERENCES public.iris_impact_themes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: llm_training_pairs llm_training_pairs_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_training_pairs
    ADD CONSTRAINT llm_training_pairs_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: query_optimization_recommendations query_optimization_recommendations_query_pattern_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.query_optimization_recommendations
    ADD CONSTRAINT query_optimization_recommendations_query_pattern_id_fkey FOREIGN KEY (query_pattern_id) REFERENCES public.query_patterns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sdg_indicators sdg_indicators_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdg_indicators
    ADD CONSTRAINT sdg_indicators_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.sdg_targets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sdg_targets sdg_targets_sdg_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sdg_targets
    ADD CONSTRAINT sdg_targets_sdg_id_fkey FOREIGN KEY (sdg_id) REFERENCES public.sustainable_development_goals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_custom_indicators user_custom_indicators_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_custom_indicators
    ADD CONSTRAINT user_custom_indicators_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_custom_indicators user_custom_indicators_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_custom_indicators
    ADD CONSTRAINT user_custom_indicators_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_custom_indicators user_custom_indicators_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_custom_indicators
    ADD CONSTRAINT user_custom_indicators_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_measurements user_measurements_custom_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_measurements
    ADD CONSTRAINT user_measurements_custom_indicator_id_fkey FOREIGN KEY (custom_indicator_id) REFERENCES public.user_custom_indicators(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_measurements user_measurements_indicator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_measurements
    ADD CONSTRAINT user_measurements_indicator_id_fkey FOREIGN KEY (indicator_id) REFERENCES public.iris_key_indicators(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_measurements user_measurements_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_measurements
    ADD CONSTRAINT user_measurements_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_measurements user_measurements_strategic_goal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_measurements
    ADD CONSTRAINT user_measurements_strategic_goal_id_fkey FOREIGN KEY (strategic_goal_id) REFERENCES public.iris_strategic_goals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_measurements user_measurements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_measurements
    ADD CONSTRAINT user_measurements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_measurements user_measurements_verified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_measurements
    ADD CONSTRAINT user_measurements_verified_by_fkey FOREIGN KEY (verified_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: user_organizations user_organizations_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_organizations user_organizations_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_organizations user_organizations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_organizations
    ADD CONSTRAINT user_organizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_reports user_reports_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_reports
    ADD CONSTRAINT user_reports_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: user_reports user_reports_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_reports
    ADD CONSTRAINT user_reports_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

